__author__ = 't'

from subprocess import Popen, PIPE, call
import logging


# [system]
SYS_USERNAME = "test"
SYS_PASSWORD = "testpassword"

# [SITE]
SITE_NAME = "mysite"
# [MYSQL]
PASSWORD = "password"
MYSQL_ROOT_PASSWORD = "test123"
MYSQL_ROOT_NEW_PASSWORD = "test123"
MYSQL_ROOT_OLD_PASSWORD = "test123"
MYSQL_DBNAME = "testing"


def logit(cmd, cmdoutput, cmderr):
    logger = logging.getLogger("OMNIKNIGHT")
    if cmd != "":
        logger.debug("command: "+cmd)
    if cmdoutput !="":
        logger.debug("command output: "+cmdoutput)
    if cmderr !="":
        logger.debug("command error: "+cmderr)
