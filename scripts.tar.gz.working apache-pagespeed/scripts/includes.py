__author__ = 't'

from subprocess import Popen, PIPE, call
import logging


# [system]
SYS_USERNAME = "test"
SYS_PASSWORD = "testpassword"

# [SITE]
SITE_NAME = "mysite"
# [MYSQL]
PASSWORD = "password"
MYSQL_ROOT_PASSWORD = "test123"
MYSQL_ROOT_NEW_PASSWORD = "test123"
MYSQL_ROOT_OLD_PASSWORD = "test123"
MYSQL_DBNAME = "testing"

logger = logging.getLogger("OMNIKNIGHT")

def logit(cmd, cmdoutput, cmderr):
    if cmd != "":
        logger.debug("command: " + cmd)
    if cmdoutput != "":
        logger.debug("command output: " + cmdoutput)
    if cmderr != "":
        logger.debug("command error: " + cmderr)


def check_nginx_present(self):
    cmd = "nginx -v 2>&1 > /dev/null | grep nginx -c"
    logger.debug(cmd)

    cmd = "nginx -v 2>&1 > /dev/null"
    a = Popen([cmd], stdout=PIPE, stderr=PIPE, shell=True)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)

    a = Popen(["grep", "nginx", "-c"], stdin=a.stdout, stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    if cmdoutput != "0":
        return True
    else:
        return False


def check_nginx_enabled(self):
    cmd = "pidof -c nginx"
    logger.debug(cmd)

    a = Popen(cmd.split(), stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    if cmdoutput == "":
        return False
    else:
        return True


def check_apache2_present(self):
    cmd = "apache2 -v 2>&1 > /dev/null | grep apache -c"
    logger.debug(cmd)

    cmd = "apache2 -v 2>&1 > /dev/null"
    a = Popen([cmd], stdout=PIPE, stderr=PIPE, shell=True)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)

    a = Popen(["grep", "apache", "-c"], stdin=a.stdout, stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    if cmdoutput != "0":
        return True
    else:
        return False


def check_apache2_enabled(self):
    cmd = "pidof -c apache2"
    logger.debug(cmd)

    a = Popen(cmd.split(), stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    if cmdoutput == "":
        return False
    else:
        return True