__author__ = 't'

from subprocess import Popen, PIPE, call
import logging


# [system]
SYS_USERNAME = "test"
SYS_PASSWORD = "testpassword"

# [SITE]
SITE_NAME = "mysite"
# [MYSQL]
PASSWORD = "password"
MYSQL_ROOT_PASSWORD = "test123"
MYSQL_ROOT_NEW_PASSWORD = "test123"
MYSQL_ROOT_OLD_PASSWORD = "test123"
MYSQL_DBNAME = "testing"


PHPFPM_NGINX_SERVER = "echo \"upstream php {\n" \
                "\tserver unix:/tmp/php5-fpm.sock;\n" \
                "}\""

PMA_APACHE_SERVER = "echo " \
                  "     \"Alias /phpmyadmin \"/usr/share/phpmyadmin\"\n" \
                  "     Alias /phpMyAdmin \"/usr/share/phpmyadmin\"\n" \
                  "     <Directory /usr/share/phpmyadmin>\n" \
                  "         \tOptions Indexes FollowSymLinks\n" \
                  "         \tAllowOverride None\n" \
                  "         \tOrder allow,deny\n" \
                  "         \tallow from all\n" \
                  "     </Directory>\""

PMA_NGINX_SERVER =  "echo \"server {\n" \
                    "\tlisten 8080;" \
                    "\troot /usr/share/phpmyadmin;\n" \
                    "\tindex index.php\n" \
                    "\tlocation / {\n" \
                    "\t\ttry_files $uri $uri/ /index.php;\n" \
                    "\t}\n" \
                    "\tlocation ~ \.php$ {\n" \
                    "\t\tfastcgi_split_path_info ^(.+\.php)(/.+)$;\n" \
                    "\t\tfastcgi_pass php;\n" \
                    "\t\tfastcgi_index index.php;\n" \
                    "\t\tfastcgi_param SCRIPT_FILENAME /usr/share/phpmyadmin$fastcgi_script_name;\n" \
                    "\t\tfastcgi_param DOCUMENT_ROOT /usr/share/phpmyadmin;\n" \
                    "\t\tfastcgi_intercept_errors on;\n" \
                    "\t\tinclude fastcgi_params;\n" \
                    "\t}\n" \
                    "}\""

WORDPRESS_APACHE_SERVER = "echo \"<VirtualHost *:80> \n" \
                    "\tServerAdmin webmaster@localhost\n" \
                    "\n" \
                    "\tDocumentRoot /home/test/public_html\n" \
                    "\t<Directory />\n" \
                    "\t\tOptions FollowSymLinks\n" \
                    "\t\tAllowOverride All\n" \
        	        "\t</Directory>\n" \
        	        "\n" \
        	        "\tErrorLog ${APACHE_LOG_DIR}/error.log\n" \
        	        "\n" \
        	        "\t# Possible values include: debug, info, notice, warn, error, crit,\n" \
        	        "\t# alert, emerg.\n" \
        	        "\tLogLevel warn\n" \
        	        "\n" \
        	        "\tCustomLog ${APACHE_LOG_DIR}/access.log combined\n" \
        	        "</VirtualHost>\""

WORDPRESS_NGINX_SERVER =  "echo \"server {\n" \
                    "\tlisten 80;" \
                    "\troot /home/"+SYS_USERNAME+"/public_html;\n" \
                    "\tindex index.php\n" \
                    "\tlocation / {\n" \
                    "\t\ttry_files $uri $uri/ /index.php;\n" \
                    "\t}\n" \
                    "\tlocation ~ \.php$ {\n" \
                    "\t\tfastcgi_split_path_info ^(.+\.php)(/.+)$;\n" \
                    "\t\tfastcgi_pass php;\n" \
                    "\t\tfastcgi_index index.php;\n" \
                    "\t\tfastcgi_param SCRIPT_FILENAME /home/"+SYS_USERNAME+"/public_html$fastcgi_script_name;\n" \
                    "\t\tfastcgi_param DOCUMENT_ROOT /home/"+SYS_USERNAME+"/public_html;\n" \
                    "\t\tfastcgi_intercept_errors on;\n" \
                    "\t\tinclude fastcgi_params;\n" \
                    "\t}\n" \
                    "}\""

logger = logging.getLogger("OMNIKNIGHT")

def logit(cmd, cmdoutput, cmderr):
    if cmd != "":
        logger.debug("command: " + cmd)
    if cmdoutput != "":
        logger.debug("command output: " + cmdoutput)
    if cmderr != "":
        logger.debug("command error: " + cmderr)


def check_nginx_present():
    cmd = "nginx -v 2>&1 > /dev/null | grep nginx -c"
    logger.debug(cmd)

    cmd = "nginx -v 2>&1 > /dev/null"
    a = Popen([cmd], stdout=PIPE, stderr=PIPE, shell=True)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)

    a = Popen(["grep", "nginx", "-c"], stdin=a.stdout, stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    logit(cmd,cmdoutput,errmsg)
    if cmdoutput != "0":
        return True
    else:
        return False


def check_nginx_enabled():
    cmd = "pidof -c nginx"
    #logger.debug(cmd)

    a = Popen(cmd.split(), stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    logit(cmd,cmdoutput,errmsg)
    if cmdoutput == "":
        return False
    else:
        return True


def check_apache2_present():
    cmd = "apache2 -v 2>&1 > /dev/null | grep apache -c"
    logger.debug(cmd)

    cmd = "apache2 -v 2>&1 > /dev/null"
    a = Popen([cmd], stdout=PIPE, stderr=PIPE, shell=True)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)

    a = Popen(["grep", "apache", "-c"], stdin=a.stdout, stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    logit(cmd,cmdoutput,errmsg)
    if cmdoutput != "0":
        return True
    else:
        return False


def check_apache2_enabled():
    cmd = "pidof -c apache2"

    a = Popen(cmd.split(), stdout=PIPE, stderr=PIPE, shell=False)
    errmsg = a.stderr.read()
    if errmsg != "":
        logger.error(errmsg)
    cmdoutput = a.stdout.read()
    logit(cmd,cmdoutput,errmsg)
    if cmdoutput == "":
        return False
    else:
        return True